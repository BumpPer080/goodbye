
import React from 'react';
import { Profile } from '../types';

interface WelcomeBackProps {
  profile: Profile;
  onStart: () => void;
  onSwitch: () => void;
}

const WelcomeBack: React.FC<WelcomeBackProps> = ({ profile, onStart, onSwitch }) => {
  return (
    <div className="relative min-h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Cinematic Backdrop */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-transparent to-background-dark z-10"></div>
        <div 
          className="w-full h-full bg-cover bg-center scale-110" 
          style={{ backgroundImage: "url('https://picsum.photos/seed/movie/1920/1080?blur=10')" }}
        />
        <div className="absolute inset-0 cinematic-blur z-20"></div>
      </div>

      {/* Header Branding */}
      <div className="absolute top-0 left-0 w-full z-50 px-10 py-6">
        <div className="flex items-center gap-2 text-white">
          <div className="size-8 text-primary">
            <svg fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path d="M39.5563 34.1455V13.8546C39.5563 15.708 36.8773 17.3437 32.7927 18.3189C30.2914 18.916 27.263 19.2655 24 19.2655C20.737 19.2655 17.7086 18.916 15.2073 18.3189C11.1227 17.3437 8.44365 15.708 8.44365 13.8546V34.1455C8.44365 35.9988 11.1227 37.6346 15.2073 38.6098C17.7086 39.2069 20.737 39.5564 24 39.5564C27.263 39.5564 30.2914 39.2069 32.7927 38.6098C36.8773 37.6346 39.5563 35.9988 39.5563 34.1455Z" />
            </svg>
          </div>
          <h2 className="text-white text-2xl font-bold leading-tight tracking-tight uppercase">StreamFlow</h2>
        </div>
      </div>

      {/* Greeting Card */}
      <main className="relative z-30 px-6 w-full max-w-[520px]">
        <div className="bg-[#2a1a1b] rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col items-center text-center p-10 md:p-14 animate-in fade-in zoom-in duration-500">
          <div className="mb-8 relative">
            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full scale-150"></div>
            <div className="relative bg-primary text-white size-20 rounded-full flex items-center justify-center shadow-lg shadow-primary/30">
              <span className="material-symbols-outlined !text-4xl">auto_awesome</span>
            </div>
          </div>

          <div className="mb-4">
            <div className={`size-16 rounded-full border-2 border-primary/30 p-1`}>
              <div className={`w-full h-full rounded-full flex items-center justify-center bg-gradient-to-br ${profile.color}`}>
                 <span className="material-symbols-outlined text-white text-2xl opacity-70">
                  {profile.icon}
                 </span>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-10">
            <h1 className="text-white text-3xl md:text-4xl font-bold tracking-tight">
              ยินดีต้อนรับกลับมา!
            </h1>
            <p className="text-[#c89295] text-lg leading-relaxed max-w-sm">
              ขอให้เป็นวันที่ดีและสนุกกับการรับชมนะ เตรียมป๊อปคอร์นให้พร้อมแล้วเริ่มเลย
            </p>
          </div>

          <button 
            onClick={onStart}
            className="group relative w-full flex items-center justify-center gap-3 overflow-hidden rounded-lg h-14 bg-primary text-white text-lg font-semibold transition-all hover:bg-red-700 hover:shadow-xl hover:shadow-primary/20"
          >
            <span className="relative z-10">เริ่มรับชมเลย</span>
            <span className="material-symbols-outlined relative z-10 transition-transform group-hover:translate-x-1">play_circle</span>
            <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
          </button>

          <button 
            onClick={onSwitch}
            className="mt-6 text-[#c89295] text-sm font-medium hover:text-white transition-colors"
          >
            ไม่ใช่คุณใช่ไหม? สลับโปรไฟล์
          </button>
        </div>
      </main>

      {/* Cinematic Footer Overlay */}
      <footer className="absolute bottom-0 w-full z-40 px-10 py-8 flex flex-col md:flex-row items-center justify-between text-[#c89295] text-xs">
        <div className="flex items-center gap-6 mb-4 md:mb-0">
          <a className="hover:text-white transition-colors" href="#">นโยบายความเป็นส่วนตัว</a>
          <a className="hover:text-white transition-colors" href="#">เงื่อนไขการใช้งาน</a>
          <a className="hover:text-white transition-colors" href="#">ศูนย์ช่วยเหลือ</a>
        </div>
        <div className="text-right opacity-60">
          © 2024 StreamFlow Entertainment. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default WelcomeBack;
