
import React, { useState, useEffect, useRef } from 'react';
import { Profile } from '../types';

interface PinEntryProps {
  profile: Profile;
  onSuccess: () => void;
  onExit: () => void;
}

const PinEntry: React.FC<PinEntryProps> = ({ profile, onSuccess, onExit }) => {
  const [pin, setPin] = useState(['', '', '', '']);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;

    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);

    // Auto focus next
    if (value && index < 3) {
      inputsRef.current[index + 1]?.focus();
    }

    // Check if full
    if (newPin.every(v => v !== '')) {
      // Mock validation
      setTimeout(() => onSuccess(), 500);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 relative min-h-screen bg-background-alt">
      <header className="w-full px-8 py-6 flex items-center justify-between absolute top-0 left-0 z-10">
        <div className="flex items-center gap-2">
          <div className="text-primary">
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path d="M39.5563 34.1455V13.8546C39.5563 15.708 36.8773 17.3437 32.7927 18.3189C30.2914 18.916 27.263 19.2655 24 19.2655C20.737 19.2655 17.7086 18.916 15.2073 18.3189C11.1227 17.3437 8.44365 15.708 8.44365 13.8546V34.1455C8.44365 35.9988 11.1227 37.6346 15.2073 38.6098C17.7086 39.2069 20.737 39.5564 24 39.5564C27.263 39.5564 30.2914 39.2069 32.7927 38.6098C36.8773 37.6346 39.5563 35.9988 39.5563 34.1455Z" />
            </svg>
          </div>
          <span className="text-xl font-bold text-white uppercase tracking-widest">StreamFlow</span>
        </div>
        <div className="flex items-center gap-6">
          <button className="text-sm font-medium text-white/70 hover:text-primary transition-colors">Help Center</button>
          <div className={`h-10 w-10 rounded bg-gradient-to-br ${profile.color} flex items-center justify-center overflow-hidden`}>
             <span className="material-symbols-outlined text-white text-xl">{profile.icon}</span>
          </div>
        </div>
      </header>

      <div className="max-w-md w-full flex flex-col items-center space-y-12">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-lg overflow-hidden border-4 border-transparent hover:border-white/20 transition-all duration-300">
             <div className={`w-full h-full bg-gradient-to-br ${profile.color} flex items-center justify-center`}>
                <span className="material-symbols-outlined text-white text-6xl opacity-80">{profile.icon}</span>
             </div>
          </div>
          <div className="text-center space-y-2">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white">Profile Lock is on.</h1>
            <p className="text-[#a3a3a3] text-lg font-normal">Enter your PIN to access this profile.</p>
          </div>
        </div>

        <form className="flex gap-4 md:gap-6 justify-center">
          {pin.map((digit, i) => (
            <input
              key={i}
              ref={el => inputsRef.current[i] = el}
              type="password"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={e => handleChange(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              className="pin-input w-16 h-16 md:w-20 md:h-20 text-center text-3xl md:text-4xl font-bold rounded-lg bg-transparent border border-white/20 text-white focus:ring-0"
              autoFocus={i === 0}
            />
          ))}
        </form>

        <div className="flex flex-col items-center space-y-8">
          <button className="text-[#a3a3a3] hover:text-white transition-colors text-sm font-medium underline underline-offset-4 decoration-[#404040] hover:decoration-white">
            Forgot PIN?
          </button>
          <button 
            onClick={onExit}
            className="px-8 py-3 rounded-md bg-white/10 hover:bg-white/20 text-white font-bold transition-all text-sm uppercase tracking-wider"
          >
            Exit Profile
          </button>
        </div>
      </div>

      <footer className="absolute bottom-0 w-full p-8 flex justify-center text-[#555] text-xs uppercase tracking-[0.2em] font-medium">
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-sm">lock</span>
          Secure Profile Access
        </div>
      </footer>
    </div>
  );
};

export default PinEntry;
