
import React from 'react';
import { PROFILES } from '../constants';
import { Profile } from '../types';

interface ProfileSelectionProps {
  onSelect: (profile: Profile) => void;
}

const ProfileSelection: React.FC<ProfileSelectionProps> = ({ onSelect }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-20">
      <header className="absolute top-0 left-0 w-full px-8 py-6 md:px-14 flex items-center gap-2 text-primary">
        <div className="size-8">
          <svg fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
            <path d="M39.5563 34.1455V13.8546C39.5563 15.708 36.8773 17.3437 32.7927 18.3189C30.2914 18.916 27.263 19.2655 24 19.2655C20.737 19.2655 17.7086 18.916 15.2073 18.3189C11.1227 17.3437 8.44365 15.708 8.44365 13.8546V34.1455C8.44365 35.9988 11.1227 37.6346 15.2073 38.6098C17.7086 39.2069 20.737 39.5564 24 39.5564C27.263 39.5564 30.2914 39.2069 32.7927 38.6098C36.8773 37.6346 39.5563 35.9988 39.5563 34.1455Z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold tracking-tight">StreamFlow</h2>
      </header>

      <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-semibold mb-12 tracking-wide text-center">
        Who's watching?
      </h1>

      <div className="max-w-6xl w-full flex flex-wrap justify-center gap-6 md:gap-8 lg:gap-10 p-4">
        {PROFILES.map((profile) => (
          <button
            key={profile.id}
            onClick={() => onSelect(profile)}
            className="group flex flex-col items-center gap-4 outline-none focus:ring-2 focus:ring-primary rounded-lg p-2 transition-transform active:scale-95"
          >
            <div className={`w-32 h-32 md:w-40 md:h-40 bg-gradient-to-br ${profile.color} rounded-lg shadow-xl flex items-center justify-center text-4xl overflow-hidden border-3 border-transparent group-hover:border-white group-hover:scale-105 transition-all duration-300 relative`}>
              <span className="material-symbols-outlined text-6xl opacity-80 text-white">
                {profile.icon}
              </span>
              {profile.isLocked && (
                <div className="absolute bottom-2 right-2 bg-black/40 p-1 rounded-full flex items-center justify-center">
                  <span className="material-symbols-outlined text-sm text-white/80">lock</span>
                </div>
              )}
            </div>
            <p className="text-gray-400 text-lg md:text-xl font-medium transition-colors group-hover:text-white">
              {profile.name}
            </p>
          </button>
        ))}
      </div>

      <div className="mt-20">
        <button className="px-8 py-3 border border-gray-500 text-gray-500 hover:text-white hover:border-white transition-all text-lg tracking-widest font-light uppercase outline-none focus:ring-2 focus:ring-primary">
          Manage Profiles
        </button>
      </div>
    </div>
  );
};

export default ProfileSelection;
