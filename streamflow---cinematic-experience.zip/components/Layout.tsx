
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      {/* Background Gradient */}
      <div className="fixed inset-0 bg-background-dark -z-10" />
      
      {children}
      
      {/* Sticky footer for branding on most screens (except maybe cinematic ones) */}
      <footer className="mt-auto py-10 text-center text-gray-600 text-sm z-10">
        <p>© 2024 StreamFlow. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Layout;
