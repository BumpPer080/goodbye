
import { Profile, SpecialCard } from './types';

export const PROFILES: Profile[] = [
  { id: '1', name: 'User 1', icon: 'person', color: 'from-blue-500 to-indigo-600', isLocked: false },
  { id: '2', name: 'User 2', icon: 'sentiment_satisfied', color: 'from-red-500 to-pink-600', isLocked: true },
  { id: '3', name: 'User 3', icon: 'flutter_dash', color: 'from-green-500 to-teal-600', isLocked: false },
  { id: '4', name: 'User 4', icon: 'pets', color: 'from-yellow-400 to-orange-500', isLocked: false },
  { id: '5', name: 'User 5', icon: 'mist', color: 'from-purple-500 to-violet-700', isLocked: false },
  { id: '6', name: 'User 6', icon: 'rocket_launch', color: 'from-cyan-400 to-blue-600', isLocked: false },
  { id: '7', name: 'User 7', icon: 'star', color: 'from-emerald-400 to-green-600', isLocked: false },
];

export const CARDS: SpecialCard[] = [
  {
    id: 'c1',
    type: 'illustration',
    title: 'Thanks a Ton.',
    series: 'Punny Animals',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDaQvB89BnQAc4cfdd7A3h0CIdixwRuqAY6S4gSe50id7_nWz4Ntp79cn84NsFa9lHJutpfQJCq2uNhqA4T2MSh1AAMGEgwR8f5BRdUWI2msw4hydr2hdaAtfZ7Ez3HMm6Rlko7_B9apXfSI6bGbkZez2pP4ze0niIuTkBMkUJJ5xBkxjckrbB8bCYjuCFHbOPA1Uusl82WnDgvzm3ITqT8xSmdj_uw1jLDj68D8gMOkVg410jm5UYvpjPMtA1MR5rFYK5nXHKQcbe6',
    bgColor: 'bg-card-cream'
  },
  {
    id: 'c2',
    type: 'photo',
    recipient: 'Rob',
    author: 'Jordan',
    message: "Thank you for all the coaching, laughs, adventures, and show recommendations. You've been a phenomenal manager and I wish you well in your new \"day-to-day\". Although it won't be nearly as frequent, I look forward to our check-in calls as you move into this new role!",
    series: 'Team Memories',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAASSCIUuvfNrfVG89z3SOGhLeU067JBLPrwceJVv6Q8Q4ciWYL-iQl6hrjvP1oZRiTXV7aAJ8j1ExgZ-s48H8alXzlFRlgy0x4JctUk7ULPxp_YDivr6uwoTjF5-Mpgr3lZ5IYrs1MrnxgSHADiZ6b0AZ2Lj2frUQzPomfpxiOHIK7jNYkxoctnjfBc59chp8o13DBJ5CndMRa2-9UGfXZf9_7b1dANleMRCucWsC7EclxLJ2ZbyzhzyriS3H_M8Fr-eSIeSTnNdVM',
    bgColor: 'bg-white'
  }
];
